﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CustomerApi.Models
{
    public class Customer
    {
        public int Autokey { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [StringLength(50)]
        public string MiddleName { get; set; } = string.Empty;

        [Required]
        [MinLength(10, ErrorMessage = "Address should be at least 10 characters long.")] // Changed length for simplicity
        public string Address { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Date)]
        public DateTime? Birthdate { get; set; }

        public Customer(string lastName, string firstName, string middleName, string address, DateTime? birthdate)
        {
            LastName = lastName;
            FirstName = firstName;
            MiddleName = middleName;
            Address = address;
            Birthdate = birthdate;
        }
    }
}
